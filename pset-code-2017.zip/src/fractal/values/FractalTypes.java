package fractal.values;

public enum FractalTypes {
    INTEGER,
	REAL,
	FRACTAL,
	FRAC_APPROX;
}
